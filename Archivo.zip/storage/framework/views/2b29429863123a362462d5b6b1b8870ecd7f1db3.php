<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Impresión Definitiva</title>
  <link rel="stylesheet" type="text/css" href="<?php echo e(url('bower_components/bootstrap/dist/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('bower_components/bootstrap-material-design/dist/css/bootstrap-material-design.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('bower_components/bootstrap-material-design/dist/css/ripples.min.css')); ?>">
    <script type="text/javascript" src=" <?php echo e(url('bower_components/jquery/dist/jquery.min.js')); ?>"></script>
    <script type="text/javascript" src=" <?php echo e(url('bower_components/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>
    <script type="text/javascript" src=" <?php echo e(url('bower_components/bootstrap-material-design/dist/js/ripples.min.js')); ?>"></script>
    <script type="text/javascript" src=" <?php echo e(url('bower_components/bootstrap-material-design/dist/js/material.min.js')); ?>"></script>
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('css/estilo.css')); ?>">
</head>
  <body>
    <div id="contenido">
    <table align="right">
        <tr>
          <td colspan="2" align="right"><b>Morelia, Mich.,&nbsp; <?php echo e($date); ?></b></td>
        </tr>
        <tr>
          <td colspan="2" align="right"><b>DEPENDENCIA:&nbsp;</b>SUB. ACADÉMICA</td>
        </tr>
        <tr>
          <td colspan="2" align="right"><b>SECCIÓN:&nbsp;</b><?php echo e($secc); ?></td>
        </tr>
        <tr>
          <td colspan="2" align="right"><b>OFICIO:&nbsp;</b><?php echo e($nof); ?></td>
        </tr>
        <tr>
          <td colspan="2" align="right">&nbsp;</td>
        </tr>
        <tr>
          <td colspan="2" align="right"><b>ASUNTO:&nbsp;</b> Impresión definitiva</td>
        </tr>
    </table>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <div class="col-md-12" id="den">
      <p>
        <strong>
          <?php $__currentLoopData = $jefediv; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $div): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $docente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($docente->completo); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <br>
          <?php $__currentLoopData = $gjdiv; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genero): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($genero->sexo_empleado=='M'): ?> JEFE <?php else: ?> JEFA <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> DE LA DIVISIÓN DE ESTUDIOS PROFESIONALES
          <br>
        </strong>
      </p>
      <p align="justify">
        Los que suscriben, integrantes del Jurado de Examen Recepcional del egresado (a) cuyos datos se especifican a continuación:
      </p>
      <table class="table table-bordered" bordercolor="black">
        <tbody>
            <?php $__currentLoopData = $data3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td>Nombre del egresado (a):</td>
            <td><?php echo e($t->completo); ?></td>
          </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td>Número de control</td>
            <td><?php echo e($nc); ?></td>
          </tr>
            <?php $__currentLoopData = $data2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td>Pasante de la carrera de:</td>
            <td><?php echo e($t->nombre); ?></td>
          </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td>Opción de Titulación</td>
            <td><?php echo e($t->opcion); ?></td>
          </tr>
          <tr>
            <td>Título final del trabajo de Titulación</td>
            <td>"<?php echo e($t->proyecto); ?>"</td>
          </tr>

        </tbody>
        </table>
        <p align="justify">
          Hacemos constar que hemos revisando su informe técnico y tenemos a bien comunicarle nuestra autorización para la liberación del mismo y su impresión definitiva.
        </p>
      </div>
      <div id="firmas">
            <p align="center"><strong>ATENTAMENTE</strong><br>
            </p>
            <br>
            <div class="col-md-12">
              <table align="center">
                <thead>
                  <tr>
                    <th>&nbsp;</th>
                    <th>&nbsp;</th>
                    <th>&nbsp;</th>
                  </tr>
                    <tr>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                  </tr>
                    <tr>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td align="center"><?php echo e($t->presidente); ?></td>
                    <td align="center">&nbsp;</td>
                    <td align="center"><?php echo e($t->secretario); ?></td>
                  </tr>
                  <tr>
                    <td align="center" id="titulo">PRESIDENTE & ASESOR</td>
                    <td align="center">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                    <td align="center" id="titulo">SECRETARIO</td>
                  </tr>
                  <tr>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                  </tr>
                    <tr>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                  </tr>
                    <tr>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                  </tr>
                  <tr>
                    <td align="center"><?php echo e($t->vocal_propietario); ?></td>
                    <td align="center">&nbsp;</td>
                    <td align="center"><?php echo e($t->vocal_suplente); ?></td>
                  </tr>
                  <tr>
                    <td align="center" id="titulo">VOCAL PROPIETARIO</td>
                    <td align="center">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                    <td align="center" id="titulo">VOCAL SUPLENTE</td>
                  </tr>
                </tbody>
                </table>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <p id="cp">C.C.P. Alumno</p>
    </div>
    </div>
  </body>
</html>
