<?php $__env->startSection('content'); ?>
        <div class="col-md-8 col-md-offset-2">
                    <div class="content">
                        <div class="title m-b-md">
                            Modulo de Apoyo a Proyecto Docencia
                        </div>
                    </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>