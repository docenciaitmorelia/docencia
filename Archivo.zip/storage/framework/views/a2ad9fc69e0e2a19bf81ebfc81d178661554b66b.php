<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>Asignación de Revisores</title>
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('css/estilo.css')); ?>">
</head>
  <body>
    <div id="contenido">
			<p align='right'> Morelia, Mich. a <?php echo e($date); ?> </p>
      <p align="center">
        <strong>
          <?php echo e($seccion->descripcion_area); ?>

          <br>
          REVISORES PARA OPCIÓN DE TITULACIÓN
        </strong>
      </p>
      <br>
      <table border="1" bordercolor="black" width="100%">
          <tbody>
            <tr>
              <td><?php if($data3->sexo == 'M'): ?>Alumno: <?php else: ?> Alumna: <?php endif; ?></td>
              <td><?php echo e($data3->completo); ?></td>
            </tr>
            <tr>
              <td>Opción de Titulación:</td>
              <td><?php echo e($data->nombre_opcion); ?></td>
            </tr>
            <tr>
              <td>Título del trabajo</td>
              <td>"<?php echo e($data->nombre_proyecto); ?>"</td>
            </tr>
            <tr>
              <td>Asesor</td>
              <td> <?php echo e($data->ag); ?> <?php echo e($data->asesor); ?></td>
            </tr>
          </tbody>
        </table>
        <p align="justify">
          <strong>REVISORES</strong>
        </p>
        <table border="1" bordercolor="black" width="100%">
          <thead>
            <tr>
              <th>Cargo</th>
              <th>Nombre del(la) profesor(a)</th>
              <th>Firma</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>Presidente</td>
              <td> <?php echo e($data->pg); ?> <?php echo e($data->presidente); ?></td>
              <td width="20%"></td>
            </tr>
            <tr>
              <td>Secretario</td>
              <td><?php echo e($data->sg); ?> <?php echo e($data->secretario); ?></td>
              <td></td>
            </tr>
            <tr>
              <td>Vocal Propietario</td>
              <td><?php echo e($data->vpg); ?> <?php echo e($data->vocal_propietario); ?></td>
              <td></td>
            </tr>
            <tr>
              <td>Vocal Suplente</td>
              <td> <?php if($vs == '0'): ?> <?php echo e($data->asesor_externo); ?> <?php else: ?> <?php echo e($data->vsg); ?> <?php echo e($data->vocal_suplente); ?> <?php endif; ?> </td>
              <td></td>
            </tr>
          </tbody>
        </table>
				<br>
				<div id="firmas">
	            <p align="center"><strong>ATENTAMENTE</strong><br>
	              <i id="tec">"Técnica, progreso de México"</i>
	            </p>
	            <br>
	            <div class="col-md-12">
	              <table align="center">
	                <thead>
	                  <tr>
	                    <th width='30%'>&nbsp;</th>
	                    <th width='30%'>&nbsp;</th>
	                    <th width='30%'>&nbsp;</th>
	                  </tr>
	                </thead>
	                <tbody>
										<tr>
	                    <td>&nbsp;</td>
	                    <td>&nbsp;</td>
	                    <td>&nbsp;</td>
	                  </tr>
	                  <tr>
	                    <td align="center"><?php echo e($seccion->jefe_area); ?></td>
	                    <td align="center">&nbsp;</td>
	                    <td align="center"><?php echo e($academia->grado); ?> <?php echo e($academia->nombre_empleado); ?> <?php echo e($academia->apellidos_empleado); ?></td>
	                  </tr>
	                  <tr>
	                    <td align="center" id="titulo">JEFE DEL <?php echo e($seccion->descripcion_area); ?></td>
	                    <td align="center">&nbsp;</td>
	                    <td align="center" id="titulo">PRESIDENTE DE ACADEMIA</td>
	                  </tr>

										<tr>
	                    <td>&nbsp;</td>
	                    <td>&nbsp;</td>
	                    <td>&nbsp;</td>
	                  </tr>

										<tr>
	                    <td>&nbsp;</td>
	                    <td align="center"><?php echo e($data->ag); ?> <?php echo e($data->asesor); ?></td>
	                    <td>&nbsp;</td>
	                  </tr>
										<tr>
	                    <td>&nbsp;</td>
	                    <td align="center">ASESOR</td>
	                    <td>&nbsp;</td>
	                  </tr>
	                </tbody>
	                </table>
	            </div>
    </div>
  </body>
</html>
