<?php $__env->startSection('content'); ?>
<?php $__currentLoopData = $alumno; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $al): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="row">
	<div class="col">
		<div class="card">
		  <div class="card-body">
		    <h3 class="card-title"> <center>Liberación de Proyecto</center></h3>
<center>
<div class="col-md-12">
<br>
<h4> <b><?php echo e($al->no_de_control); ?> — <?php echo e($al->apellido_paterno); ?> <?php echo e($al->apellido_materno); ?> <?php echo e($al->nombre_alumno); ?></b></h4>
</div>
</center>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__currentLoopData = $titulacion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $titu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<center><h5><i><?php echo e($titu->nombre_opcion); ?></i></h5></center>

					<table class="table table-striped table-hover">
						<thead>
							<tr>
								<th><center>Asesor</center></th>
								<th> <center>Presidente</center></th>
								<th> <center>Secretario</center></th>
								<th> <center>Vocal Propietario</center></th>
								<th> <center>Vocal Suplente</center></th>
								<th colspan="1"></th>
							</tr>
						</thead>
						<tbody>

								<tr>
									<td><?php echo e($titu->asesor); ?></td>

									<td>
										<?php echo e($titu->presidente); ?>

									</td>

									<td>
										<?php echo e($titu->secretario); ?>

									</td>

									<td>
										<?php echo e($titu->vocal_suplente); ?>

									</td>

				                    <td>
										<?php echo e($titu->vocal_suplente); ?>

									</td>
								</tr>
						</tbody>
					</table>
					<br>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<form action="../crear_liberacion_p/<?php echo e($al->no_de_control); ?>" method="POST" target="_blank">
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<div class="col-md-12">
							<div class="col-md-6">
								<label for="seccion" class="control-label">Sección</label>
								<input type="text" id="seccion" name="seccion" class="form-control" placeholder="SISTEMAS Y COMPUTACIÓN" style="text-transform:uppercase;" required>
							</div>
							</div>
								<div class="col-md-12">
							<div class="col-md-6">
								<label for="oficio" class="control-label">Oficio</label>
								<input type="text" id="oficio" name="oficio" class="form-control" placeholder="DSC-D-001/2018" required>
							</div>
						</div>
						<p class="col-md-12">
							<button type="submit" class="btn btn-raised btn-primary">Generar PDF</button>
							<a href="<?php echo e(route('titulaciones.index')); ?>" class="btn btn-raised btn-primary">Regresar</a>
						</p>
					</form>
				</div>
			</div>
		</div>
	</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>