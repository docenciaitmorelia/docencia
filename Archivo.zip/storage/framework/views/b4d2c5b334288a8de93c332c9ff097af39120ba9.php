<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Liberación de Proyecto</title>
  <link rel="stylesheet" type="text/css" href="<?php echo e(url('bower_components/bootstrap/dist/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('bower_components/bootstrap-material-design/dist/css/bootstrap-material-design.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('bower_components/bootstrap-material-design/dist/css/ripples.min.css')); ?>">
    <script type="text/javascript" src=" <?php echo e(url('bower_components/jquery/dist/jquery.min.js')); ?>"></script>
    <script type="text/javascript" src=" <?php echo e(url('bower_components/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>
    <script type="text/javascript" src=" <?php echo e(url('bower_components/bootstrap-material-design/dist/js/ripples.min.js')); ?>"></script>
    <script type="text/javascript" src=" <?php echo e(url('bower_components/bootstrap-material-design/dist/js/material.min.js')); ?>"></script>
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('css/estilo.css')); ?>">
</head>
  <body>
    <div id="contenido">
    <table align="right">
        <tr>
          <td colspan="2" align="right"><b>Morelia, Mich.,&nbsp; <?php echo e($date); ?></b></td>
        </tr>
        <tr>
          <td colspan="2" align="right"><b>DEPENDENCIA:&nbsp;</b>SUB. ACADÉMICA</td>
        </tr>
        <tr>
          <td colspan="2" align="right"><b>SECCIÓN:&nbsp;</b><?php echo e($secc); ?></td>
        </tr>
        <tr>
          <td colspan="2" align="right"><b>OFICIO:&nbsp;</b><?php echo e($nof); ?></td>
        </tr>
        <tr>
          <td colspan="2" align="right">&nbsp;</td>
        </tr>
        <tr>
          <td colspan="2" align="right"><b>ASUNTO:&nbsp;</b> Liberación de Proyecto para Titulación Integral</td>
        </tr>
    </table>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <div class="col-md-12" id="den">
      <p>
        <strong>
          <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $docente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($docente->grado); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $docente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($docente->completo); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <br>
          <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $docente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($docente->sexo=='M'): ?> JEFE <?php else: ?> JEFA <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> DE LA DIVISIÓN DE ESTUDIOS PROFESIONALES
          <br>
        </strong>
      </p>
      <p align="justify">
        Por este medio, le informo que ha sido liberado el siguiente proyecto para la Titulación Integral.
      </p>
      <table class="table table-bordered" bordercolor="black">
          <tbody>
              <?php $__currentLoopData = $data3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td>Nombre del egresado (a):</td>
              <td><?php echo e($t->completo); ?></td>
            </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td>Número de control</td>
              <td><?php echo e($nc); ?></td>
            </tr>
              <?php $__currentLoopData = $data2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td>Carrera de:</td>
              <td><?php echo e($t->nombre); ?></td>
            </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td>Opción de Titulación</td>
              <td><?php echo e($t->opcion); ?></td>
            </tr>
            <tr>
              <td>Nombre del proyecto:</td>
              <td>"<?php echo e($t->proyecto); ?>"</td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
        <p align="justify">
          Agradezco de antemano su valioso apoyo en esta importante actividad para la formación profesional de nuestros egresados.
        </p>
      </div>
      <div id="firmas">
            <p align="center"><strong>ATENTAMENTE</strong><br>
              <i id="tec">"Técnica, progreso de México"</i>
            </p>
            <br>
            <div class="col-md-12">
              <table align="center">
                <thead>
                  <tr>
                    <th>&nbsp;</th>
                    <th>&nbsp;</th>
                    <th>&nbsp;</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td align="center">NOMBRE</td>
                    <td align="center">Nombre</td>
                    <td align="center">NOMBRE</td>
                  </tr>
                  <tr>
                    <td align="center" id="titulo">Jefe del Depto</td>
                    <td align="center">Asesor</td>
                    <td align="center" id="titulo">Presidente de Academia</td>
                  </tr>
                </tbody>
                </table>
            </div>
            <p id="cp">C.p. Asesor<br>Alumno interesado<br>Archivo</p>
    </div>
    </div>
  </body>
</html>
