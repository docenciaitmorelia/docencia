<?php $__env->startSection('content'); ?>
<?php $__currentLoopData = $alumno; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $al): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="row">
	<div class="col">
		<div class="card">
		  <div class="card-body">
		    <h3 class="card-title"> <center>Asignación de Revisores</center></h3>
				<center>
				<div class="col-md-12">
				<br>
				<h4> <b><?php echo e($al->no_de_control); ?> — <?php echo e($al->apellido_paterno); ?> <?php echo e($al->apellido_materno); ?> <?php echo e($al->nombre_alumno); ?></b></h4>
				</div>
				</center>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php $__currentLoopData = $titulacion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $titu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<hr>
				<center><h5><i><?php echo e($titu->nombre_opcion); ?></i></h5></center>

				<table class="table table-striped table-hover">
					<thead>
						<tr>
							<th colspan="2"><center>Asesor</center></th>
							<th colspan="2"> <center>Presidente</center></th>
							<th colspan="2"> <center>Secretario</center></th>
							<th colspan="2"> <center>Vocal Propietario</center></th>
							<th colspan="2"> <center>Vocal Suplente</center></th>
							<th colspan="1"></th>
						</tr>
					</thead>
					<tbody>

							<tr>
								<td><input type="t_asesor" name="t_asesor" class="form-control" placeholder="DR."></td><td> <?php echo e($titu->asesor); ?></td>

								<td><input type="t_presidente" name="t_presidente" class="form-control" placeholder="DR."></td><td><?php echo e($titu->presidente); ?>

								</td>

								<td><input type="t_secretario" name="t_secretario" class="form-control" placeholder="DR."></td><td><?php echo e($titu->secretario); ?>

								</td>

								<td><input type="t_vocalp" name="t_vocalp" class="form-control" placeholder="DR."></td><td><?php echo e($titu->vocal_propietario); ?>

								</td>

								 <td><input type="t_volcals" name="t_volcals" class="form-control" placeholder="DR."></td><td><?php echo e($titu->vocal_suplente); ?>

								</td>
							</tr>
					</tbody>
				</table>
					<br>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<form action="../crear_asignacion_r/<?php echo e($al->no_de_control); ?>" method="POST" target="_blank">
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<div class="col-md-12">
						<div class="col-md-6">
							<label for="depto" class="control-label">Departamento</label>
							<input type="text" id="depto" name="depto" class="form-control" placeholder="DEPARTAMENTO DE..." style="text-transform:uppercase;" required>
						</div>
						</div>
						<div class="col-md-12">
						<div class="col-md-1">
							<label>&nbsp;</label>
							<input type="text" id="t_jefedepto" name="t_jefedepto" class="form-control" placeholder="M.C." style="text-transform:uppercase;" required>
						</div>
						<div class="col-md-5">
							<label for='jefedepto' class="control-label">Jefe Departamento</label>
							<select id="jefedepto" name="jefedepto" class="form-control" required>
								<option value="">Seleccione docente</option>
								<?php $__currentLoopData = $personal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo $doc->rfc; ?>"><?php echo $doc->completo; ?>, <?php echo e($doc->rfc); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
						</div>
					<div class="col-md-1">
						<label for='t_presac' class="control-label">&nbsp;</label>
						<input type="text" id="t_presac" name="t_presac" class="form-control" placeholder="M.C." style="text-transform:uppercase;" required>
					</div>
					<div class="col-md-5">
						<label for='presac' class="control-label">Presidente de Academia</label>
						<select id="presac" name="presac" class="form-control" required>
							<option value="">Seleccione docente</option>
							<?php $__currentLoopData = $personal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo $doc->rfc; ?>"><?php echo $doc->completo; ?>, <?php echo e($doc->rfc); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
					</div>
				</div>
						<p class="col-md-12">
							<button type="submit" class="btn btn-raised btn-primary">Generar PDF</button>
							<a href="<?php echo e(route('titulaciones.index')); ?>" class="btn btn-raised btn-primary">Regresar</a>
						</p>
					</form>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>