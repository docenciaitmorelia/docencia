<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Impresión Definitiva</title>
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('css/estilo.css')); ?>">
</head>
  <body>
    <div id="contenido">
    <table align="right">
        <tr>
          <td colspan="2" align="right"><b>Morelia, Mich.,&nbsp; <?php echo e($date); ?></b></td>
        </tr>
        <tr>
          <td colspan="2" align="right"><b>DEPENDENCIA:&nbsp;</b>SUB. ACADÉMICA</td>
        </tr>
        <tr>
          <td colspan="2" align="right"><b>SECCIÓN:&nbsp;</b><?php echo e($seccion->descripcion_area); ?></td>
        </tr>
        <tr>
          <td colspan="2" align="right"><b>OFICIO:&nbsp;</b><?php echo e($nof); ?></td>
        </tr>
        <tr>
          <td colspan="2" align="right">&nbsp;</td>
        </tr>
        <tr>
          <td colspan="2" align="right"><b>ASUNTO:&nbsp;</b> Impresión definitiva</td>
        </tr>
    </table>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <div class="col-md-12" id="den">
      <p>
        <strong>
  			     <?php echo e($jefediv->jefe_area); ?>

  				<br>
  				<?php if($gjdiv->sexo_empleado=='M'): ?> JEFE <?php else: ?> JEFA <?php endif; ?> DE LA DIVISIÓN DE ESTUDIOS PROFESIONALES
  				<br>
  			</strong>
  		</p>
      <p align="justify">
        Los que suscriben, integrantes del Jurado de Examen Recepcional del egresado (a) cuyos datos se especifican a continuación:
      </p>
      <table border="1" bordercolor="black">
        <tbody>
          <tr>
            <td width="25%">Nombre <?php if($alumno->sexo=='M'): ?> del&nbsp;egresado: <?php else: ?> de&nbsp;la&nbsp;egresada: <?php endif; ?></td>
            <td><?php echo e($alumno->completo); ?></td>
          </tr>
          <tr>
            <td>Número de control:</td>
            <td><?php echo e($alumno->no_de_control); ?></td>
          </tr>
          <tr>
            <td>Pasante de la carrera de:</td>
            <td><?php echo e($carrera->nombre); ?></td>
          </tr>
          <tr>
            <td>Opción de Titulación:</td>
            <td><?php echo e($titu->nombre_opcion); ?></td>
          </tr>
          <tr>
            <td>Título final del trabajo de Titulación:</td>
            <td>"<?php echo e($titu->nombre_proyecto); ?>"</td>
          </tr>

        </tbody>
        </table>
        <p align="justify">
          Hacemos constar que hemos revisando su informe técnico y tenemos a bien comunicarle nuestra autorización para la liberación del mismo y su impresión definitiva.
        </p>
      </div>
      <div id="firmas">
            <p align="center"><strong>ATENTAMENTE</strong><br>
            </p>
            <br>
            <div class="col-md-12">
              <table align="center">
                <thead>
                  <tr>
                    <th rowspan="2" colspan="3">&nbsp;</th>
                    <th rowspan="2" colspan="3">&nbsp;</th>
                    <th rowspan="2" colspan="3">&nbsp;</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td align="center"><?php echo e($titu->pg); ?> <?php echo e($titu->presidente); ?></td>
                    <td align="center">&nbsp;</td>
                    <td align="center"><?php echo e($titu->sg); ?> <?php echo e($titu->secretario); ?></td>
                  </tr>
                  <tr>
                    <td align="center" id="titulo"><?php if($vs == '0'): ?> PRESIDENTE <?php else: ?> PRESIDENTE & ASESOR <?php endif; ?></td>
                    <td align="center">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                    <td align="center" id="titulo">SECRETARIO</td>
                  </tr>
                  <tr>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                  </tr>
                    <tr>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                  </tr>
                    <tr>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                  </tr>
                  <tr>
                    <td align="center"><?php echo e($titu->vpg); ?> <?php echo e($titu->vocal_propietario); ?></td>
                    <td align="center">&nbsp;</td>
                    <td align="center"><?php if($vs == '0'): ?> <?php echo e($titu->asesor_externo); ?> <?php else: ?> <?php echo e($titu->vsg); ?> <?php echo e($titu->vocal_suplente); ?> <?php endif; ?></td>
                  </tr>
                  <tr>
                    <td align="center" id="titulo">VOCAL PROPIETARIO</td>
                    <td align="center">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                    <td align="center" id="titulo"><?php if($vs == '0'): ?> VOCAL SUPLENTE & ASESOR <?php else: ?> VOCAL SUPLENTE <?php endif; ?></td>
                  </tr>
                </tbody>
                </table>
            </div>
            <p id="cp">C.C.P. Alumno</p>
    </div>
    </div>
  </body>
</html>
