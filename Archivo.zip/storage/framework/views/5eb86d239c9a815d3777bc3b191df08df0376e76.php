<?php $__env->startSection('content'); ?>

<?php if(Auth::user()->rol == 'Jefe de Docencia'): ?>
<?php echo $__env->make('titulaciones.fragment.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="row">
	<div class="col">
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h3 class="modal-title" id="exampleModalLabel">Filtrar Alumnos</h3>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<form role="form" role="form" id="modalform1" action="#" method="GET">
					<?php echo csrf_field(); ?>
					<div class="col-md-6 form-group">
						<input type="text" id="busqueda" name="busqueda" style="text-transform:uppercase;" placeholder="Nombre o número de control..." class="form-control">
					</div>
					<div class="col-md-2">
						<button type="submit" class="btn btn-raised btn-primary"><i class="material-icons">search</i></button>
					</div>
				</form>
				<table style="width:100%" class="table table-striped table-hover">
					<thead class="thead-dark">
						<tr>
							<th>No. Control</th>
							<th>Apellido Paterno</th>
							<th>Apellido Materno</th>
							<th>Nombre(s)</th>
							<th>Carrera</th>
						</tr>
					</thead>
					<tbody>
						<?php $__currentLoopData = $alumnos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($alumno->no_de_control); ?></td>
							<td><?php echo e($alumno->apellido_paterno); ?></td>
							<td><?php echo e($alumno->apellido_materno); ?></td>
							<td><?php echo e($alumno->nombre_alumno); ?></td>
							<td><?php echo e($alumno->reticula); ?>/<?php echo e($alumno->nombre_reducido); ?></td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
			</table>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
				<button type="button" class="btn btn-primary">Aceptar</button>
			</div>
		</div>
	</div>
</div>
</div>
</div>
<div class="row">
	<div class="col">
		<div class="card">
		  <div class="card-body">
		    <h3 class="card-title">Registro de Expediente de Titulación</h3>
					<form id="formTitulacion" action="<?php echo e(route('titulaciones.store')); ?>" method="POST" class="form">
						<?php echo csrf_field(); ?>
						<div class="form-group col-md-6">
								<label for="alumno" class="bmd-label-floating col-form-label"><?php echo e(__('Alumno')); ?></label>
										<select id="alumno" type="text" class="form-control<?php echo e($errors->has('alumno') ? ' is-invalid' : ''); ?>" name="alumno" value="" required autofocus>
											<option value="">Seleccione alumno...</option>
											<?php $__currentLoopData = $alumnos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option value="<?php echo e($alumno->no_de_control); ?>"><?php echo e($alumno->apellido_paterno); ?> <?php echo e($alumno->apellido_materno); ?> <?php echo e($alumno->nombre_alumno); ?></option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</select>
										<?php if($errors->has('alumno')): ?>
												<span class="invalid-feedback" role="alert">
														<strong><?php echo e($errors->first('alumno')); ?></strong>
												</span>
										<?php endif; ?>
						</div>
						<div class="form-group col-md-1 inline">
							<a type="button" for="alumno" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal"><i class="material-icons">search</i></a>
						</div>


						<div class="form-group col-md-5">
							<label for="opc_titu" class="control-label">Opción de titulación</label>
							<select id="opc_titu" name="opc_titu" class="form-control" required>
								<option value="">Seleccione Opción de titulación</option>
								<?php $__currentLoopData = $planes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $op): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option value="<?php echo e($op->id); ?>"><?php echo e($op->reticula); ?>/<?php echo $op->opcion_titulacion; ?> <?php echo $op->nombre_opcion; ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
						</div>

						<div class="form-group col-md-12">
							<label for="proyecto" class="control-label">Nombre del proyecto</label>
							<input type="text" id="proyecto" name="proyecto" class="form-control" style="text-transform:uppercase;" required>
						</div>
						<br>
						<hr>
						<br>
						<div class="form-group col-md-12">
							<label for="asesor" class="control-label">Asesor</label>
							<select id="asesor" name="asesor" class="form-control" required>
								<option value="">Seleccione Asesor</option>
								<?php $__currentLoopData = $personal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo $doc->rfc; ?>"><?php echo $doc->completo; ?>, <?php echo e($doc->rfc); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
						</div>

						<div class="form-group col-md-6">
							<label for="presidente" class="control-label">Presidente</label>
							<select id="presidente" name="presidente" class="form-control" required>
								<option value="">Seleccione Presidente</option>
								<?php $__currentLoopData = $personal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo $doc->rfc; ?>"><?php echo $doc->completo; ?>, <?php echo e($doc->rfc); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
						</div>

						<div class="form-group col-md-6">
							<label for="secretario" class="control-label">Secretario</label>
							<select id="secretario" name="secretario" class="form-control" required>
								<option value="">Seleccione Secretario</option>
								<?php $__currentLoopData = $personal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo $doc->rfc; ?>"><?php echo $doc->completo; ?>, <?php echo e($doc->rfc); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
						</div>

						<div class="form-group col-md-6">
							<label for="vocal_propietario" class="control-label">Vocal Propietario</label>
							<select id="vocal_propietario" name="vocal_propietario" class="form-control" required>
								<option value="">Seleccione Vocal Propietario</option>
								<?php $__currentLoopData = $personal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo $doc->rfc; ?>"><?php echo $doc->completo; ?>, <?php echo e($doc->rfc); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
						</div>

					    <div class="form-group col-md-6">
							<label for="vocal_suplente" class="control-label">Vocal Suplente</label>
							<select id="vocal_suplente" name="vocal_suplente" class="form-control">
								<option value="0">Seleccione Vocal Suplente</option>
								<?php $__currentLoopData = $personal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo $doc->rfc; ?>"><?php echo $doc->completo; ?>, <?php echo e($doc->rfc); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
						</div>

						<div class="form-group col-md-6">
							<input type="checkbox" id="aec" name="aec" onchange="myFunction()">Asesor Externo
						</div>

						<div class="form-group col-md-6" style="display: none;" id="aediv" name="aediv">
							<label for="ae" class="control-label">Nombre del Asesor</label>
							<input type="text" id="ae" name="ae" class="form-control" value="" style="text-transform:uppercase;">
						</div>

						<p class="form-group col-md-12">
							<button type="submit" class="btn btn-raised btn-primary" onclick="validarFormulario()">Guardar</button>
							<a data-toggle="modal" data-target="#modal1" class="btn btn-raised btn-primary">Cancelar</a>
						</p>


						<!-- Modal Structure -->
						<div id="modal1" class="modal" tabindex="-1" role="dialog">
							<div class="modal-dialog" role="document">
								<div class="modal-content">
									<div class="modal-header">
										<h3 class="modal-title">Eliminar</h3>
										<button type="button" class="close" data-dismiss="modal" aria-label="Close">
											<span aria-hidden="true">&times;</span>
										</button>
									</div>
									<div class="modal-body">
										<form action="<?php echo e(route('procesotitulacion.index')); ?>" method="POST" id='form-modal1'>
												<?php echo e(csrf_field()); ?>

										</form>
										<p>¿Seguro de que desea cancelar?</p>
									</div>
									<div class="modal-footer">
										<a href="<?php echo e(route('titulaciones.index')); ?>" type="button" class="btn btn-primary" >Aceptar</a>
										<button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
									</div>
								</div>
							</div>
						</div> <!-- end modal structure -->

					</form>
		  </div>
		</div>
	</div>
</div>

<script type="text/javascript">
function myFunction() {
   if($('#aec').prop('checked')) {
         $('#aediv').css('display','block');
				 $("#vocal_suplente").prop('disabled', true);
       } else {
         $('#aediv').css('display','none');
				 $("#vocal_suplente").prop('disabled', false);
       }
		 }
	function validarFormulario(){
		 $("#formTitulacion").validate();
		 var asesor = $('#asesor').val();
		 alert(asesor);
		 var presidente = $('#presidente').val();
		 if(asesor==presidente){
			 alert('son iguales');
		 }
	}
	$(document).ready(function(){
		 validarFormulario();
	});

</script>

<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>