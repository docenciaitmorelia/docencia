<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Proyecto Docencia</title>

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <!-- Fonts and Icons -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <!-- Styles -->
    <style>

        .content {
            text-align: center;
        }

        .title {
            font-size: 84px;
        }

        .m-b-md {
            margin-bottom: 30px;
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.7.5/css/bootstrap-select.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('bower_components/bootstrap/dist/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('bower_components/bootstrap-material-design/dist/css/bootstrap-material-design.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('bower_components/bootstrap-material-design/dist/css/ripples.min.css')); ?>"></head>
<body>
        <div class="navbar navbar-default">
        <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-responsive-collapse">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
        </div>
        <div class="navbar-collapse collapse navbar-responsive-collapse">
          <ul class="nav navbar-nav">
            <?php if(auth()->guard()->guest()): ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                </li>
                <?php if(Route::has('register')): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                    </li>
                <?php endif; ?>
            <?php else: ?>
              <?php switch(Auth::user()->rol):
              case ("Jefe de Docencia"): ?>
                <li class="dropdown">
                  <a href="bootstrap-elements.html" data-target="#" class="dropdown-toggle" data-toggle="dropdown">Círc. Estudios
                    <b class="caret"></b></a>
                  <ul class="dropdown-menu">
                    <li><a href="<?php echo e(route('grupocestudio.index')); ?>">Grupos Círculos de Estudios </a></li>
                    <li><a href="<?php echo e(route('gen_lista_c')); ?>">Lista de tutores</a></li>
                    <li><a href="<?php echo e(route('gen_horario')); ?>">Horario </a></li>
                  </ul>
                </li>
                <li class="dropdown">
                  <a href="bootstrap-elements.html" data-target="#" class="dropdown-toggle" data-toggle="dropdown">Titulaciones
                    <b class="caret"></b></a>
                  <ul class="dropdown-menu">
                    <li><a href="<?php echo e(route('titulaciones.index')); ?>">Titulaciones </a></li>
                    <!--<li><a href="<?php echo e(route('gen_reporte_a')); ?>">Reporte por año </a></li>
                    <li><a href="<?php echo e(route('gen_reporte_d')); ?>">Reporte por docente </a></li>
                    <li><a href="<?php echo e(route('revisiones.index')); ?>">Revisiones </a></li>-->
                  </ul>
                </li>

                <li><a href="<?php echo e(route('actividadescomp.index')); ?>">Actividades Complementarias</a></li>
                <li><a href="<?php echo e(route('catalogoac.index')); ?>">Catalogo Act.</a></li>
              <?php break; ?>
              <?php case ("DivEstProf"): ?>
                <li><a href="<?php echo e(route('procesotitulacion.index')); ?>">Proceso de Titulacion </a></li>
                <li><a href="<?php echo e(route('opcionestitulacionCtl.index')); ?>">Opciones de Titulacion </a></li>
              <?php break; ?>
              <?php case ("Docente"): ?>
                <li><a href="<?php echo e(route('proyectoTitulacionCtl.index')); ?>">Proyectos de Titulación Asignados</a></li>
              <?php break; ?>
              <?php case ("Alumno"): ?>
                <li><a href="<?php echo e(route('showRevisiones',Auth::user()->name)); ?>">Ver el Status de Mi Proyecto de Titulación</a></li>
              <?php break; ?>
              <?php case ("Administrador"): ?>
                <li><a href="<?php echo e(route('usuariosCtl.index')); ?>">Usuarios</a></li>
              <?php break; ?>
              <?php endswitch; ?>
                <li class="nav-item dropdown">
                    <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                        <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                    </a>

                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                           onclick="event.preventDefault();
                                         document.getElementById('logout-form').submit();">
                            <?php echo e(__('Logout')); ?>

                        </a>

                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>
                    </div>
                </li>
            <?php endif; ?>
          </ul>
        </div>
      </div>
    </div>
    <div class="container">
            <?php echo $__env->yieldContent('content'); ?>
    </div>

    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script type="text/javascript" src=" <?php echo e(url('bower_components/jquery/dist/jquery.min.js')); ?>"></script>
    <script type="text/javascript" src=" <?php echo e(url('bower_components/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>
    <script type="text/javascript" src=" <?php echo e(url('bower_components/bootstrap-material-design/dist/js/ripples.min.js')); ?>"></script>
    <script type="text/javascript" src=" <?php echo e(url('bower_components/bootstrap-material-design/dist/js/material.min.js')); ?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.7.5/js/bootstrap-select.min.js"></script>
    <script>
      $(document).ready(function()
      {
        $('body').bootstrapMaterialDesign();
      });
      $.material.init();
    </script>
</body>
</html>
