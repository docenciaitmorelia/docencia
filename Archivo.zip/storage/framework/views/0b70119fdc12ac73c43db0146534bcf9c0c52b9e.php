<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col">
		<div class="card">
		  <div class="card-body">
		    <h3 class="card-title">Expediente de proceso de titulación</h3>

				<?php $__currentLoopData = $alumno; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $al): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<center>
				<div class="col-md-12">
					<h3> <b><?php echo e($al->no_de_control); ?> — <?php echo e($al->apellido_paterno); ?> <?php echo e($al->apellido_materno); ?> <?php echo e($al->nombre_alumno); ?></b></h3>
				</div>
				</center>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php $__currentLoopData = $titulacion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $titu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<hr>
				<center><h5><i><?php echo e($titu->nombre_opcion); ?><br>Estatus de proceso de Titulación: <?php echo e($estatus); ?></i></h5></center>

					<table class="table table-striped table-hover">
						<thead>
							<tr>
								<th><center>Asesor</center></th>
								<th><center>Presidente</center></th>
								<th><center>Secretario</center></th>
								<th><center>Vocal Propietario</center></th>
								<th><center>Vocal Suplente</center></th>
								<th colspan="1"></th>
							</tr>
						</thead>
						<tbody>

								<tr>
									<td><?php echo e($titu->asesor); ?></td>

									<td>
										<?php echo e($titu->presidente); ?>

									</td>

									<td>
										<?php echo e($titu->secretario); ?>

									</td>

									<td>
										<?php echo e($titu->vocal_propietario); ?>

									</td>

				                    <td>
										<?php echo e($titu->vocal_suplente); ?>

									</td>

									<td>
										<a href="<?php echo e(route('titulaciones.edit', $titu->id)); ?>" class="btn btn-raised btn-primary"><i class="material-icons">create</i></a>
									</td>
								</tr>
						</tbody>
					</table>
					<br>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				    <div class="col-md-6">
				    <p>Proceso de titulación: </p>
						<?php if($orden=='Alta'): ?>
							<p>
								No hay documentos generados
							</p>
						<?php else: ?>
				    <?php $__currentLoopData = $proceso; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				        <input type="checkbox" name="proceso" value="<?php echo e($p->orden); ?>" <?php if($orden >= $p->orden): ?> checked='' disabled=''> <p class="label label-success"><?php echo e($p->descripcion); ?> <?php else: ?> disabled=''> <p class="label label-default"><?php echo e($p->descripcion); ?><?php endif; ?></p><br>
				    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>
				    </div>
				    <div class="col-md-6">
				    <?php if($estatus=='ACTIVO'): ?>
					<form action="<?php echo e(route('gen_documentos', $al->no_de_control)); ?>" method="POST">
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<div class="col-md-12">
							<label for="documento" class="control-label">Tipo de Documento</label>
							<select id="documento" type="text" class="form-control" name="documento" value="" required autofocus>
								<option value="">Seleccione documento</option>
									<?php $__currentLoopData = $proceso; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $documento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option id="documento" value="<?php echo e($documento->descripcion); ?>"><?php echo e($documento->descripcion); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						  </select>
						</div>
						<p class="col-md-12">
							<button type="submit" class="btn btn-raised btn-primary">Generar Documento</button>
							<a href="<?php echo e(route('titulaciones.index')); ?>" class="btn btn-raised btn-primary">Regresar</a>
						</p>
					</form>
				    </div>
				<?php else: ?>
				    <p class="col-md-12">
							<a href="<?php echo e(route('titulaciones.index')); ?>" class="btn btn-raised btn-primary">Regresar</a>
						</p>
				</div>
			</div>
		</div>
	</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /Users/proyectosgedocencia/Documents/Docencia/docencia/resources/views/titulaciones/fragment/detallestitu.blade.php */ ?>