<?php $__env->startSection('content'); ?>
	<h3>Generar reporte por año</h3>
	<form action="crear_reporte_a" method="POST" class="form" target="_blank">
		<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
		<div class="input-field col s6">
			<div class="col-md-4 form-group">
				<label class="control-label" for="anio">Año</label>
				<input type="text" class="form-control" id="anio1" name="anio1" value="2017">
			</div>

			<p class="col-md-12 form-group">
				<button type="submit" class="btn btn-raised btn-primary">Generar Reporte</button>
				<a href="<?php echo e(route('titulaciones.index')); ?>" class="btn btn-raised btn-primary">Regresar</a>
			</p>
	</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>