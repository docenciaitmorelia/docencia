<?php $__env->startSection('content'); ?>
<?php $__currentLoopData = $alumno; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $al): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="row">
	<div class="col">
		<div class="card">
		  <div class="card-body">
		    <h3 class="card-title"> <center>Invitación a Ceremonia de Titulación</center></h3>
				<center>
				<div class="col-md-12">
				<br>
				<h4> <b><?php echo e($al->no_de_control); ?> — <?php echo e($al->apellido_paterno); ?> <?php echo e($al->apellido_materno); ?> <?php echo e($al->nombre_alumno); ?></b></h4>
				</div>
				</center>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php $__currentLoopData = $titulacion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $titu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<hr>
				<center><h5><i><?php echo e($titu->nombre_opcion); ?></i></h5></center>
				<form action="<?php echo e(route('crear_invitacion', $al->no_de_control)); ?>" method="POST" target="_blank">
					<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

					<table class="table table-striped table-hover">
						<thead>
							<tr>
								<th colspan="2"><center>Asesor</center></th>
								<th colspan="2"> <center>Presidente</center></th>
								<th colspan="2"> <center>Secretario</center></th>
								<th colspan="2"> <center>Vocal Propietario</center></th>
								<th colspan="2"> <center>Vocal Suplente</center></th>
								<th colspan="1"></th>
							</tr>
						</thead>
						<tbody>

								<tr>
									<td><input type="t_asesor" name="t_asesor" class="form-control" placeholder="DR."></td><td> <?php echo e($titu->asesor); ?></td>

									<td><input type="t_presidente" name="t_presidente" class="form-control" placeholder="DR."></td><td><?php echo e($titu->presidente); ?>

									</td>

									<td><input type="t_secretario" name="t_secretario" class="form-control" placeholder="DR."></td><td><?php echo e($titu->secretario); ?>

									</td>

									<td><input type="t_vocalp" name="t_vocalp" class="form-control" placeholder="DR."></td><td><?php echo e($titu->vocal_propietario); ?>

									</td>

				           <td><input type="t_volcals" name="t_volcals" class="form-control" placeholder="DR."></td><td><?php echo e($titu->vocal_suplente); ?>

									</td>
								</tr>
						</tbody>
					</table>
					<br>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

						<div class="col-md-12">
						<div class="col-md-6">
							<label for="depto" class="control-label">Departamento</label>
							<input type="text" id="depto" name="depto" class="form-control" placeholder="DEPARTAMENTO DE..." style="text-transform:uppercase;" required>
						</div>
						</div>
						<div class="col-md-12">
						<div class="col-md-4">
							<label for="fecha" class="control-label">Fecha de Ceremonia</label>
							<input type="date" name="fecha" class="form-control">
						</div>
						<div class="col-md-4">
							<label for="lugar" class="control-label">Lugar</label>
							<input type="text" id="lugar" name="lugar" class="form-control" placeholder="SALA DE TITULACIÓN 1" style="text-transform:uppercase;" required>
						</div>
           <div class="col-md-4">
             <label for="hora" class="control-label">Hora</label>
             <input type="text" id="hora" name="hora" class="form-control" placeholder="9:00 HORAS" style="text-transform:uppercase;" required>
           </div>
          </div>
						<p class="col-md-12">
							<button type="submit" class="btn btn-raised btn-primary">Generar PDF</button>
							<a href="<?php echo e(route('titulaciones.index')); ?>" class="btn btn-raised btn-primary">Regresar</a>
						</p>
					</form>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>