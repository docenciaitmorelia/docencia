

<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col">
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h3 class="modal-title" id="exampleModalLabel">Filtrar Alumnos</h3>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<form role="form" role="form" id="modalform1" action="#" method="GET">
					<?php echo csrf_field(); ?>
					<div class="col-md-6 form-group">
						<input type="text" id="busqueda" name="busqueda" style="text-transform:uppercase;" placeholder="Nombre o número de control..." class="form-control">
					</div>
					<div class="col-md-2">
						<button type="submit" class="btn btn-raised btn-primary"><i class="material-icons">search</i></button>
					</div>
				</form>
				<table style="width:100%" class="table table-striped table-hover">
					<thead class="thead-dark">
						<tr>
							<th>No. Control</th>
							<th>Apellido Paterno</th>
							<th>Apellido Materno</th>
							<th>Nombre(s)</th>
							<th>Carrera</th>
						</tr>
					</thead>
					<tbody>
						<?php $__currentLoopData = $alumnos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($alumno->no_de_control); ?></td>
							<td><?php echo e($alumno->apellido_paterno); ?></td>
							<td><?php echo e($alumno->apellido_materno); ?></td>
							<td><?php echo e($alumno->nombre_alumno); ?></td>
							<td><?php echo e($alumno->reticula); ?>/<?php echo e($alumno->nombre_reducido); ?></td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
			</table>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
				<button type="button" class="btn btn-primary">Aceptar</button>
			</div>
		</div>
	</div>
</div>
</div>
</div>

<div class="row">
  <div class="col">
    <div class="card">
      <div class="card-body">
				<div class="col-md-12">
					<h3><center>Registrar Actividad Complementaria</center></h3>

<?php echo $__env->make('actividadescomp.fragment.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<form action="<?php echo e(route('actividadescomp.store')); ?>" method="POST" class="form">
		<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
		<div class="col-md-12">
	<div class="col-md-6">
		<label for="actividad" class="control-label">Nombre de la Actividad</label>
		<input type="text" id="actividad" name="actividad" class="form-control" style="text-transform:uppercase;" >
	</div>

	<div class="form-group col-md-5">
			<label for="alumno" class="bmd-label-floating col-form-label"><?php echo e(__('Alumno')); ?></label>
					<select id="alumno" type="text" class="form-control<?php echo e($errors->has('alumno') ? ' is-invalid' : ''); ?>" name="alumno" value="" required autofocus>
						<option value="">Seleccione alumno...</option>
						<?php $__currentLoopData = $alumnos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($alumno->no_de_control); ?>"><?php echo e($alumno->apellido_paterno); ?> <?php echo e($alumno->apellido_materno); ?> <?php echo e($alumno->nombre_alumno); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
					<?php if($errors->has('alumno')): ?>
							<span class="invalid-feedback" role="alert">
									<strong><?php echo e($errors->first('alumno')); ?></strong>
							</span>
					<?php endif; ?>
	</div>
	<div class="form-group col-md-1 inline">
		<a type="button" for="alumno" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal"><i class="material-icons">search</i></a>
	</div>
</div>
<div class="col-md-12">
    <div class="col-md-6">
		<label for="tipo" class="control-label">Tipo de Actividad</label>
		<select id="tipo" name="tipo" class="form-control" data-live-search="true">
			<option value="tipo">Seleccione Tipo de actividad</option>
			<?php $__currentLoopData = $tipo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<option value="<?php echo $t->id; ?>"><?php echo $t->actividad; ?></option>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</select>
	</div>

	<div class="col-md-3">
		<label for="creditos" class="control-label">Número de créditos</label>
		<input type="number" id="creditos" name="creditos" max="2" class="form-control">
	</div>

    <div class="col-md-3">
		<label for="horas" class="control-label">Horas</label>
		<input type="number" id="horas" name="horas" class="form-control" value="0">
	</div>
</div>
<div class="col-md-12">
	<div class="col-md-6">
		<label for="fecha_del" class="control-label">Del</label>
		<input type="text" id="fecha_del" name="fecha_del" class="form-control" style="text-transform:uppercase;" placeholder="12/02/2018">
	</div>

	<div class="col-md-6">
		<label for="fecha_al" class="control-label">Al</label>
		<input type="text" id="fecha_al" name="fecha_al" class="form-control" style="text-transform:uppercase;" >
	</div>
</div>
<div class="col-md-12">
	<div class="col-md-4">
		<label for="calificacion" class="control-label">Calificación</label>
		<input type="number" id="calificacion" name="calificacion" class="form-control" value="0">
	</div>

	<div class="col-md-8">
		<label for="docente_resp" class="control-label">Docente responsable</label>
		<select id="docente_resp" name="docente_resp" class="form-control" data-live-search="true">
			<option value="">Seleccione docente</option>
			<?php $__currentLoopData = $docente; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<option value="<?php echo $doc->rfc; ?>"><?php echo $doc->completo; ?></option>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</select>
	</div>
</div>

    <p class="col-md-12">
		<button type="submit" class="btn btn-raised btn-primary">Guardar</button>
		<a href="<?php echo e(route('actividadescomp.index')); ?>" class="btn btn-raised btn-primary">Cancelar</a>
	</p>


</form>
</div>
</div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>