<?php $__env->startSection('content'); ?>
<?php if(Auth::user()->rol == 'Jefe de Docencia' || Auth::user()->rol == 'Alumno'): ?>
<div class="row">
	<div class="col">
		<div class="card">
		  <div class="card-body">
		    <h3 class="card-title">Expediente de Propuesta y Proyecto de Titulación</h3>

  				<div class="col-md-6">
  					<strong>Alumno: </strong><?php echo e($alumno->no_de_control); ?> — <?php echo e($alumno->apellido_paterno); ?> <?php echo e($alumno->apellido_materno); ?> <?php echo e($alumno->nombre_alumno); ?>

  				</div>

          <div class="col-md-12">
  					<strong>Proyecto:</strong> <?php echo e($titulacion->nombre_proyecto); ?>

  				</div>
          <div class="col-md-6">
            <strong>Opción de Titulación:</strong> <?php echo e($titulacion->nombre_opcion); ?>

          </div>
          <div class="col-md-6">
            <strong>Asesor(a):</strong> <?php echo e($titulacion->asesor); ?>

          </div>
					<table class="table table-striped table-hover">
            <caption><h3>Propuesta de Proyecto</h3></caption>
						<thead>
							<tr>
                <th></th>
								<th><center>Presidente</center></th>
								<th><center>Secretario</center></th>
								<th><center>Vocal Propietario</center></th>
								<th><center>Vocal Suplente</center></th>
							</tr>
						</thead>
						<tbody>

								<tr>
                  <td><strong>Revisores:</strong></td>
									<td><?php echo e($titulacion->presidente); ?></td>
									<td><?php echo e($titulacion->secretario); ?></td>
									<td><?php echo e($titulacion->vocal_propietario); ?></td>
                  <td><?php echo e($titulacion->vocal_suplente); ?></td>
								</tr>
                <tr>
                  <td><strong>Veredicto:</strong></td>
                  <td>
                    <?php $__currentLoopData = $revisiones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $revision): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if($revision->revisor == $titulacion->rfc_presidente && $revision->tipo_revision == "PROPUESTA"): ?>
                        <?php echo e($revision->veredicto); ?> el <?php echo e($revision->fecha_revision); ?><BR>
                      <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </td>
                  <td>
                    <?php $__currentLoopData = $revisiones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $revision): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if($revision->revisor == $titulacion->rfc_secretario && $revision->tipo_revision == "PROPUESTA"): ?>
                        <?php echo e($revision->veredicto); ?> el <?php echo e($revision->fecha_revision); ?><BR>
                      <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </td>
                  <td>
                    <?php $__currentLoopData = $revisiones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $revision): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if($revision->revisor == $titulacion->rfc_vocal_propietario && $revision->tipo_revision == "PROPUESTA"): ?>
                        <?php echo e($revision->veredicto); ?> el <?php echo e($revision->fecha_revision); ?><BR>
                      <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </td>
                  <td>
                    <?php $__currentLoopData = $revisiones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $revision): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if($revision->revisor == $titulacion->rfc_vocal_suplente && $revision->tipo_revision == "PROPUESTA"): ?>
                        <?php echo e($revision->veredicto); ?> el <?php echo e($revision->fecha_revision); ?><BR>
                      <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </td>
                </tr>
                <tr>
                  <td><strong>Observaciones:</strong></td>
                  <td>
                    <?php $__currentLoopData = $revisiones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $revision): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if($revision->revisor == $titulacion->rfc_presidente && $revision->tipo_revision == "PROPUESTA"): ?>
                        <?php echo e($revision->comentarios); ?><BR>
                      <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </td>
                  <td>
                    <?php $__currentLoopData = $revisiones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $revision): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if($revision->revisor == $titulacion->rfc_secretario && $revision->tipo_revision == "PROPUESTA"): ?>
                      <?php echo e($revision->comentarios); ?><BR>
                      <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </td>
                  <td>
                    <?php $__currentLoopData = $revisiones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $revision): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if($revision->revisor == $titulacion->rfc_vocal_propietario && $revision->tipo_revision == "PROPUESTA"): ?>
                      <?php echo e($revision->comentarios); ?><BR>
                      <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </td>
                  <td>
                    <?php $__currentLoopData = $revisiones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $revision): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if($revision->revisor == $titulacion->rfc_vocal_suplente && $revision->tipo_revision == "PROPUESTA"): ?>
                      <?php echo e($revision->comentarios); ?><BR>
                      <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </td>
                </tr>
						</tbody>
					</table>


            <!-- PROYECTO DE TITULACIÓN -->

            <table class="table table-striped table-hover">
              <caption><h3>Proyecto de Titulación</h3></caption>
  						<thead>
  							<tr>
                  <th></th>
  								<th><center>Presidente</center></th>
  								<th><center>Secretario</center></th>
  								<th><center>Vocal Propietario</center></th>
  								<th><center>Vocal Suplente</center></th>
  							</tr>
  						</thead>
  						<tbody>

  								<tr>
                    <td><strong>Revisores:</strong></td>
  									<td><?php echo e($titulacion->presidente); ?></td>
  									<td><?php echo e($titulacion->secretario); ?></td>
  									<td><?php echo e($titulacion->vocal_propietario); ?></td>
                    <td><?php echo e($titulacion->vocal_suplente); ?></td>
  								</tr>
                  <tr>
                    <td><strong>Veredicto:</strong></td>
                    <td>
                      <?php $__currentLoopData = $revisiones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $revision): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($revision->revisor == $titulacion->rfc_presidente && $revision->tipo_revision == "PROYECTO"): ?>
                          <?php echo e($revision->veredicto); ?> el <?php echo e($revision->fecha_revision); ?><BR>
                        <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                    <td>
                      <?php $__currentLoopData = $revisiones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $revision): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($revision->revisor == $titulacion->rfc_secretario && $revision->tipo_revision == "PROYECTO"): ?>
                          <?php echo e($revision->veredicto); ?> el <?php echo e($revision->fecha_revision); ?><BR>
                        <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                    <td>
                      <?php $__currentLoopData = $revisiones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $revision): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($revision->revisor == $titulacion->rfc_vocal_propietario && $revision->tipo_revision == "PROYECTO"): ?>
                          <?php echo e($revision->veredicto); ?> el <?php echo e($revision->fecha_revision); ?><BR>
                        <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                    <td>
                      <?php $__currentLoopData = $revisiones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $revision): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($revision->revisor == $titulacion->rfc_vocal_suplente && $revision->tipo_revision == "PROYECTO"): ?>
                          <?php echo e($revision->veredicto); ?> el <?php echo e($revision->fecha_revision); ?><BR>
                        <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                  </tr>
                  <tr>
                    <td><strong>Observaciones:</strong></td>
                    <td>
                      <?php $__currentLoopData = $revisiones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $revision): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($revision->revisor == $titulacion->rfc_presidente && $revision->tipo_revision == "PROYECTO"): ?>
                          <?php echo e($revision->comentarios); ?><BR>
                        <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                    <td>
                      <?php $__currentLoopData = $revisiones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $revision): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($revision->revisor == $titulacion->rfc_secretario && $revision->tipo_revision == "PROYECTO"): ?>
                        <?php echo e($revision->comentarios); ?><BR>
                        <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                    <td>
                      <?php $__currentLoopData = $revisiones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $revision): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($revision->revisor == $titulacion->rfc_vocal_propietario && $revision->tipo_revision == "PROYECTO"): ?>
                        <?php echo e($revision->comentarios); ?><BR>
                        <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                    <td>
                      <?php $__currentLoopData = $revisiones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $revision): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($revision->revisor == $titulacion->rfc_vocal_suplente && $revision->tipo_revision == "PROYECTO"): ?>
                        <?php echo e($revision->comentarios); ?><BR>
                        <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                  </tr>
  						</tbody>
  					</table>
						<div class="col-md-12">
							<?php if(Auth::user()->rol == 'Jefe de Docencia'): ?>
									<a href="<?php echo e(route('titulaciones.index')); ?>" class="btn btn-raised btn-primary"><i class="material-icons">chevron_left</i>Regresar</a>
							<?php elseif(Auth::user()->rol == 'Alumno'): ?>
								<a href="<?php echo e(route('home')); ?>" class="btn btn-raised btn-primary"><i class="material-icons">chevron_left</i>Regresar</a>
							<?php endif; ?>
						</div>
				</div>
			</div>
		</div>
	</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>