<?php $__env->startSection('content'); ?>

<?php if(Auth::user()->rol == 'Jefe de Docencia'): ?>
<?php echo $__env->make('titulaciones.fragment.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="row">
	<div class="col">
		<div class="card">
		  <div class="card-body">
		    <h3 class="card-title">Editar Titulación</h3>
					<form id="formTitulacion" action="<?php echo e(route('titulaciones.update', $titulacion->id)); ?>" method="POST" class="form">
						<?php echo e(csrf_field()); ?>

						<?php echo e(method_field('PUT')); ?>

						<div class="form-group col-md-6">
								<label for="alumno" class="bmd-label-floating col-form-label"><?php echo e(__('Alumno')); ?></label>
								<input readonly type="text" id="alumno" name="alumno" class="form-control" value="<?php echo e($alumno->apellido_paterno); ?> <?php echo e($alumno->apellido_materno); ?> <?php echo e($alumno->nombre_alumno); ?>" style="text-transform:uppercase;">
										<?php if($errors->has('alumno')): ?>
												<span class="invalid-feedback" role="alert">
														<strong><?php echo e($errors->first('alumno')); ?></strong>
												</span>
										<?php endif; ?>
						</div>
						<div class="form-group col-md-5">
							<label for="opc_titu" class="control-label">Opción de titulación</label>
							<select id="opc_titu" name="opc_titu" class="form-control" required>
								<option value="">Seleccione Opción de titulación</option>
								<?php $__currentLoopData = $planes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $op): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option value="<?php echo e($op->id); ?>" <?php echo e((old('opc_titu',$titulacion->opc_titu)==$op->id)? 'selected':''); ?>><?php echo e($op->reticula); ?>/<?php echo $op->opcion_titulacion; ?> <?php echo $op->nombre_opcion; ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
						</div>

						<div class="form-group col-md-12">
							<label for="proyecto" class="control-label">Nombre del proyecto</label>
							<input type="text" id="proyecto" name="proyecto" class="form-control" style="text-transform:uppercase;" value="<?php echo e(old('proyecto', $titulacion->nombre_proyecto)); ?>" required>
						</div>
						<br>
						<hr>
						<br>
						<div class="form-group col-md-12">
							<label for="asesor" class="control-label">Asesor</label>
							<select id="asesor" name="asesor" class="form-control" required>
								<option value="0">Seleccione Asesor</option>
								<?php $__currentLoopData = $personal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo $doc->rfc; ?>" <?php echo e((old('asesor',$titulacion->asesor)==$doc->rfc)? 'selected':''); ?>><?php echo $doc->completo; ?>, <?php echo e($doc->rfc); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
						</div>

						<div class="form-group col-md-6">
							<label for="presidente" class="control-label">Presidente</label>
							<select id="presidente" name="presidente" class="form-control" required>
								<option value="">Seleccione Presidente</option>
								<?php $__currentLoopData = $personal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo $doc->rfc; ?>" <?php echo e((old('presidente',$titulacion->presidente)==$doc->rfc)? 'selected':''); ?>><?php echo $doc->completo; ?>, <?php echo e($doc->rfc); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
						</div>

						<div class="form-group col-md-6">
							<label for="secretario" class="control-label">Secretario</label>
							<select id="secretario" name="secretario" class="form-control" required>
								<option value="">Seleccione Secretario</option>
								<?php $__currentLoopData = $personal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo $doc->rfc; ?>" <?php echo e((old('secretario',$titulacion->secretario)==$doc->rfc)? 'selected':''); ?>><?php echo $doc->completo; ?>, <?php echo e($doc->rfc); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
						</div>

						<div class="form-group col-md-6">
							<label for="vocal_propietario" class="control-label">Vocal Propietario</label>
							<select id="vocal_propietario" name="vocal_propietario" class="form-control" required>
								<option value="">Seleccione Vocal Propietario</option>
								<?php $__currentLoopData = $personal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo $doc->rfc; ?>" <?php echo e((old('vocal_propietario',$titulacion->vocal_propietario)==$doc->rfc)? 'selected':''); ?>><?php echo $doc->completo; ?>, <?php echo e($doc->rfc); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
						</div>

					    <div class="form-group col-md-6">
							<label for="vocal_suplente" class="control-label">Vocal Suplente</label>
							<?php if($vs == '0'): ?>
							<input type="text" id="ae" name="ae" class="form-control" style="text-transform:uppercase;" value="<?php echo e(old('ae', $titulacion->asesor_externo)); ?>">
							<input type="text" style="display: none;" id="vocal_suplente" name="vocal_suplente" value="0">
							<?php else: ?>
							<select id="vocal_suplente" name="vocal_suplente" class="form-control" required>
								<option value="0">Seleccione Vocal Suplente</option>
								<?php $__currentLoopData = $personal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo $doc->rfc; ?>" <?php echo e((old('vocal_suplente',$titulacion->vocal_suplente)==$doc->rfc)? 'selected':''); ?>><?php echo $doc->completo; ?>, <?php echo e($doc->rfc); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
							<?php endif; ?>
						</div>

						<div class="col-md-4">
							<label for="estatus" class="control-label">Estatus</label>
							<select id="estatus" name="estatus" class="form-control" required="">
								<option value="">Seleccione estatus</option>
			                    <option value="ACTIVO" <?php echo (old('estatus',$titulacion->estatus)=='ACTIVO')? 'selected':''; ?>>Activo</option>
			                    <option value="CANCELADO" <?php echo (old('estatus',$titulacion->estatus)=='CANCELADO')? 'selected':''; ?>>Cancelado</option>
							</select>
						</div>

						<p class="form-group col-md-12">
							<button type="submit" class="btn btn-raised btn-primary" onclick="validarFormulario()">Guardar</button>
							<a data-toggle="modal" data-target="#modal1" class="btn btn-raised btn-primary">Cancelar</a>
						</p>


						<!-- Modal Structure -->
						<div id="modal1" class="modal" tabindex="-1" role="dialog">
							<div class="modal-dialog" role="document">
								<div class="modal-content">
									<div class="modal-header">
										<h3 class="modal-title">Eliminar</h3>
										<button type="button" class="close" data-dismiss="modal" aria-label="Close">
											<span aria-hidden="true">&times;</span>
										</button>
									</div>
									<div class="modal-body">
										<form action="<?php echo e(route('procesotitulacion.index')); ?>" method="POST" id='form-modal1'>
												<?php echo e(csrf_field()); ?>

										</form>
										<p>¿Seguro de que desea cancelar?</p>
									</div>
									<div class="modal-footer">
										<a href="<?php echo e(route('titulaciones.index')); ?>" type="button" class="btn btn-primary" >Aceptar</a>
										<button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
									</div>
								</div>
							</div>
						</div> <!-- end modal structure -->

					</form>
		  </div>
		</div>
	</div>
</div>

<script type="text/javascript">

	function validarFormulario(){
		 $("#formTitulacion").validate();
		 var asesor = $('#asesor').val();
		 alert(asesor);
		 var presidente = $('#presidente').val();
		 if(asesor==presidente){
			 alert('son iguales');
		 }
	}
	$(document).ready(function(){
		 validarFormulario();
	});

</script>

<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>