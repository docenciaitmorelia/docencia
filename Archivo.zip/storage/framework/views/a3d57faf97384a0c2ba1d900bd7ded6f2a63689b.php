<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>Constancia de Círculo de Estudios</title>
  <link rel="stylesheet" type="text/css" href="<?php echo e(url('css/estilo.css')); ?>">

</head>
  <body>
    <div id="contenido">
    <table align="right">
        <tr>
          <td colspan="2" align="right"><b>DEPENDENCIA:&nbsp;</b>SUB. ACADÉMICA</td>
        </tr>
        <tr>
          <td colspan="2" align="right" width="25%"><b>SECCIÓN:&nbsp;</b><?php echo e($data5->descripcion_area); ?></td>
        </tr>
        <tr>
          <td colspan="2" align="right"><b>OFICIO:&nbsp;</b><?php echo e($nof); ?></td>
        </tr>
        <tr>
          <td colspan="2" align="right"><b>Morelia, Mich.,&nbsp; <?php echo e($date); ?></b></td>
        </tr>
        <tr>
          <td colspan="2" align="right">&nbsp;</td>
        </tr>
        <tr>
          <td colspan="2" align="right"><b>ASUNTO:&nbsp;</b> Constancia de asesoría de círculos de estudios</td>
        </tr>
    </table>
      <br>
      <br>
      <br>
    <br>
    <br>
    <br>
    <br>
    <br>
      <div class="col-md-12" id="den">
      <p>
        <strong>
          A quién corresponda:
        </strong>
      </p>
      <br>
      <br>
      <p align="justify">
        Por medio de la presente se hace <strong>CONSTAR</strong> que el <strong>C. <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($alumno->completo); ?>&nbsp; <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></strong> de la carrera <?php $__currentLoopData = $data4; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $carrera): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($carrera->nombre); ?>, <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> &nbsp;con número de control <?php echo e($nc); ?>, apoyó como ASESOR(A) de Círculos de estudio en la(s) materia(s) <?php $__currentLoopData = $data2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $materia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($materia->nombre); ?>, <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> &nbsp;en el periodo <?php $__currentLoopData = $data3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ciclo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($ciclo->ciclo_escolar==1): ?> ENERO-JUNIO <?php else: ?> AGOSTO-DICIEMBRE <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php echo e($anio); ?>.
      </p>

     <br>

      <p align="justify">
        Se expide la presente para los fines que al interesado convengan, y sin otro particular, le envío un cordial saludo.
      </p>
      <br>
      <br>
      <br>
      <br>
      <div id="firmas">
            <p align="center"><strong>ATENTAMENTE</strong><br>
              <i id="tec">"Técnica, progreso de México"</i>
            </p>
            <br>
            <br>
            <br>
            <div class="col-md-12">
              <table align="center">
                <thead>
                  <tr>
                    <th>&nbsp;</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td align="center"><?php echo e($data5->jefe_area); ?></td>
                  </tr>
                  <tr>
                    <td align="center" id="titulo"><?php $__currentLoopData = $gjdsc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genero): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($genero->sexo_empleado=='M'): ?> JEFE <?php else: ?> JEFA <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> DEL <?php echo e($data5->descripcion_area); ?></td>
                  </tr>
                </tbody>
                </table>
            </div>
            <p id="cp">Cp. Archivo</p>
    </div>
    </div>
      </div>
  </body>
</html>
