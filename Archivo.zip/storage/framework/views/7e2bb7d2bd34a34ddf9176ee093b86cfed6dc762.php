<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>Reporte por año</title>
  	<link rel="stylesheet" type="text/css" href="<?php echo e(url('bower_components/bootstrap/dist/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('bower_components/bootstrap-material-design/dist/css/bootstrap-material-design.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('bower_components/bootstrap-material-design/dist/css/ripples.min.css')); ?>">
    <script type="text/javascript" src=" <?php echo e(url('bower_components/jquery/dist/jquery.min.js')); ?>"></script>
    <script type="text/javascript" src=" <?php echo e(url('bower_components/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>
    <script type="text/javascript" src=" <?php echo e(url('bower_components/bootstrap-material-design/dist/js/ripples.min.js')); ?>"></script>
    <script type="text/javascript" src=" <?php echo e(url('bower_components/bootstrap-material-design/dist/js/material.min.js')); ?>"></script>
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('css/estilo.css')); ?>">
</head>
<body>

	<div id="contenido">
        <table align="right">
			<tr>
				<td colspan="2" align="right"><b>DEPENDENCIA:&nbsp;</b>SUB. ACADÉMICA</td>
			</tr>
			<tr>
				<td colspan="2" align="right"><b>SECCIÓN:&nbsp;</b>SISTEMAS Y COMPUTACIÓN</td>
			</tr>
			<tr>
				<td colspan="2" align="right"><b>OFICIO:&nbsp;</b><?php echo e($nof); ?></td>
			</tr>
			<tr>
				<td colspan="2" align="right"><b>Morelia, Mich.,&nbsp;<?php echo e($date); ?></b></td>
			</tr>
			<tr>
				<td colspan="2" align="right">&nbsp;</td>
			</tr>
			<tr>
				<td colspan="2" align="right"><b>ASUNTO:&nbsp;</b> Constancia de cumplimiento</td>
			</tr>
		</table>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<b>A QUIÉN CORRESPONDA:</b>

	<p align="justify">
		El que suscribe, Jefe del Departamento de Sistemas y Computación, hace constar que de acuerdo a la documentación que existe en registro de este departamento, se realizaron en el año las Titulaciones que a continuación se detallan:
		</p>

			<?php for($j = 1; $j <= 2; $j++): ?>
			<?php if($j==1 && count($titu1)): ?>
			<h5><b>SEMESTRE: ENERO-JUNIO</b></h5>

			<table class="table table-bordered" bordercolor="black">
				<?php $__currentLoopData = $su1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<thead>
					<tr>
						<th colspan="3"><center><?php echo e($s1->opcion); ?>: <?php echo e($s1->total); ?></center></th>
					<tr>
						<th><center>Proyecto</center></th>
						<th>Asesor</th>
						<th>Estatus</th>
					</tr>
				</thead>
				<tbody>
					<?php $__currentLoopData = $titu1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if($t->opc_titu == $s1->opc_titu): ?>
							<tr>
								<td><?php echo e($t->proyecto); ?></td>
								<td>
									<strong><?php echo e($t->asesor); ?></strong>
								</td>
								<td>
									<strong><?php echo e($t->estatus); ?></strong>
								</td>
							</tr>
						<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</table>
			<br>
			<?php elseif($j==2 && count($titu2)): ?>
			<h5><b>SEMESTRE: AGOSTO-DICIEMBRE</b></h5>
			<table class="table table-bordered">
				<?php $__currentLoopData = $su1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<thead>
					<tr><th colspan="3"><center><?php echo e($s1->opcion); ?>: <?php echo e($s1->total); ?></center></th>
					<tr>
						<th><center>Proyecto</center></th>
						<th>Asesor</th>
						<th>Estatus</th>
					</tr>
				</thead>
				<tbody>
					<?php $__currentLoopData = $titu1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if($t->opc_titu == $s1->opc_titu): ?>
							<tr>
								<td><?php echo e($t->proyecto); ?></td>
								<td>
									<strong><?php echo e($t->asesor); ?></strong>
								</td>
								<td>
									<strong><?php echo e($t->estatus); ?></strong>
								</td>
							</tr>
						<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</table>
			<?php endif; ?>
			<?php endfor; ?>
			<p>Sin otro particular, le reitero mi consideración distinguida.</p>
			<div id="firmas">
            <p align="center"><strong>ATENTAMENTE</strong><br>
              <i id="tec">"Técnica, progreso de México"</i>
            </p>
            <br>
            <br>
            <br>
            <div class="col-md-12">
              <table align="center">
                <thead>
                  <tr>
                    <th>&nbsp;</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td align="center">Nombre</td>
                  </tr>
                  <tr>
                    <td align="center" id="titulo">Jefe del Departamento de Sistemas y Computación</td>
                  </tr>
                </tbody>
                </table>
            </div>
		        <p id="cp">Cp. Archivo</p>
			</div>
		</div>
	</div>
</body>
</html>
