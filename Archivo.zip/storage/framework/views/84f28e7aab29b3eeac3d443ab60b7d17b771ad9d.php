<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>Constancia de Actividades complementarias</title>
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('css/estilo.css')); ?>">
</head>
  <body>

    <div id="contenido">
        <div id="datos1">
            <table align="right">
                <tr>
                  <td colspan="2" align="right"><b>DEPENDENCIA:&nbsp;</b>SUB. ACADÉMICA</td>
                </tr>
                <tr>
                  <td colspan="2" align="right"><b>SECCIÓN:&nbsp;</b> <?php echo e($data5->descripcion_area); ?></td>
                </tr>
                <tr>
                  <td colspan="2" align="right"><b>OFICIO:&nbsp;</b><?php echo e($nof); ?></td>
                </tr>
                <tr>
                  <td colspan="2" align="right"><b>Morelia, Mich.,&nbsp; <?php echo e($date); ?></b></td>
                </tr>
                <tr>
                  <td colspan="2" align="right">&nbsp;</td>
                </tr>
                <tr>
                  <td colspan="2" align="right"><b>ASUNTO:&nbsp;</b> Constancia de actividades complementarias</td>
                </tr>
            </table>
        </div>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <div id="servesc">
          <p align="justify">
						<?php echo e($data7->jefe_area); ?>

						<br>
						<?php $__currentLoopData = $gjesc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genero): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($genero->sexo_empleado=='M'): ?> JEFE <?php else: ?> JEFA <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> DE LA DIVISIÓN DE ESTUDIOS PROFESIONALES
						<br>
            PRESENTE
          </p>
        </div>
        <div id="texto1">
          <p align="justify">
            Por medio de la presente se hace <strong>CONSTAR</strong> que de acuerdo a los expedientes de este departamento y al seguimiento de actividades complementarias,<?php $__currentLoopData = $data2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($alumno->sexo=='M'): ?> el <?php else: ?> la <?php endif; ?> <strong>C. <?php echo e($alumno->apellido_paterno); ?> <?php echo e($alumno->apellido_materno); ?> <?php echo e($alumno->nombre_alumno); ?></strong>,<?php if($alumno->sexo=='M'): ?> alumno <?php else: ?> alumna <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> del Instituto Tecnológico de Morelia, de la carrera <?php $__currentLoopData = $data4; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $carrera): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <strong><?php echo e($carrera->nombre); ?></strong><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>, con número de control <strong><?php echo e($nc); ?></strong>, ha cumplido con los <strong>CINCO créditos correspondientes a las actividades complementarias</strong>, obteniendo un nivel de desempeño de: <strong><?php if($data3==4||$data3>=3.5): ?>Excelente, <?php elseif($data3<=3.49 && $data3>=2.5): ?> Notable, <?php elseif($data3<=2.49 && $data3>=1.5): ?> Bueno, <?php elseif($data3<=1.49 && $data3>=1): ?> Suficiente, <?php else: ?> Insuficiente, <?php endif; ?></strong> de la siguiente manera:
          </p>
        </div>
        <div id="creditos">
              <table border="1" bordercolor="black" align="center" style="height: 150px;">
                  <thead align="center">
                      <tr>
                          <th class="text-center">Actividad</th>
                          <th class="text-center">Fecha</th>
                          <th class="text-center">N. Créditos</th>
                          <th class="text-center">Calif.</th>
                      </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $acomplementaria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr style="height:20px;">
                    <td><?php echo e($acomplementaria->actividad); ?></td>
                    <td align="center">
                      <?php if($acomplementaria->fecha_del != $acomplementaria->fecha_al): ?>
                      <?php echo e($acomplementaria->fecha_del); ?> A <?php echo e($acomplementaria->fecha_al); ?>

                      <?php elseif($acomplementaria->fecha_del == $acomplementaria->fecha_al): ?>
                      <?php echo e($acomplementaria->fecha_del); ?>

                      <?php endif; ?>
                    </td>
                    <td align="center">
                      <?php echo e($acomplementaria->creditos); ?>

                    </td>
                    <td align="center">
                      <?php echo e($acomplementaria->calificacion); ?>

                    </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 <tr>
                    <td colspan="3" align="right">
                      <strong>Promedio</strong>
                    </td>
                    <td align="center">
                      <strong><?php echo e($data3); ?></strong>
                    </td>
                  </tr>
              </tbody>
            </table>
        </div>
        <div id="texto2">
            <p align="justify">
              Se emite la presente constancia para su registro correspondiente en el expediente escolar del estudiante. Agradeciendo de antemano su atención a la presente, quedo a sus órdenes.
            </p>
        </div>
        <div id="firmas">
            <p align="center">
                <strong>ATENTAMENTE</strong>
                <br>
                <i id="tec">"Técnica, progreso de México"</i>
            </p>
            <br>
            <div class="col-md-12">
                <table align="center" width='100%'>
                    <thead>
                        <tr>
                            <th>&nbsp;</th>
                            <th>&nbsp;</th>
                            <th>&nbsp;</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td align="center"><?php echo e($data5->jefe_area); ?></td>
                            <td align="center">&nbsp;</td>
                            <td align="center"><?php echo e($docencia->grado); ?> <?php echo e($docencia->nombre_empleado); ?> <?php echo e($docencia->apellidos_empleado); ?></td>
                        </tr>
                        <tr>
                            <td align="center" id="titulo"><?php if($docencia->sexo_empleado=='M'): ?> JEFE <?php else: ?> JEFA <?php endif; ?>  DEL <?php echo e($data5->descripcion_area); ?></td>
                            <td align="center">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                            <td align="center" id="titulo"><?php $__currentLoopData = $data6; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $docente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($docente->sexo=='M'): ?>JEFE <?php else: ?> JEFA <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> DEL PROYECTO DOCENCIA DEL <?php echo e($data5->descripcion_area); ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <br>
        <div id="cp">
            <p id="cp">Cp. Archivo</p>
              </div>
    </div>
  </body>
</html>
