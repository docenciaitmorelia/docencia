<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>Invitacion a Ceremonia de Titulación</title>
  <link rel="stylesheet" type="text/css" href="<?php echo e(url('bower_components/bootstrap/dist/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('bower_components/bootstrap-material-design/dist/css/bootstrap-material-design.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('bower_components/bootstrap-material-design/dist/css/ripples.min.css')); ?>">
    <script type="text/javascript" src=" <?php echo e(url('bower_components/jquery/dist/jquery.min.js')); ?>"></script>
    <script type="text/javascript" src=" <?php echo e(url('bower_components/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>
    <script type="text/javascript" src=" <?php echo e(url('bower_components/bootstrap-material-design/dist/js/ripples.min.js')); ?>"></script>
    <script type="text/javascript" src=" <?php echo e(url('bower_components/bootstrap-material-design/dist/js/material.min.js')); ?>"></script>
		<link rel="stylesheet" type="text/css" href="<?php echo e(url('css/estilo.css')); ?>">
</head>
<body>
	<div id="contenido">
			<center>
				<b>
				<h3>INSTITUTO TECNOLÓGICO DE MORELIA
				<br>
				<br>
				<br>
				<br>
				PRÓXIMA CEREMONIA DE TITULACIÓN
				</b>
				<br>
				<br>
				<br>
				<br>
				<?php echo e($date); ?>

				<br>
				<?php echo e($lugar); ?>

				<br>
				<?php echo e($hora); ?>

				</h3>
				<br>
				<br>
				<br>
				<hr style="border-color:red;">
				<?php $__currentLoopData = $data3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<h3><?php echo e($alumno->completo); ?></h3>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<hr style="border-color:red;">
				<br>
				<?php $__currentLoopData = $data2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $carrera): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<h3><?php echo e($carrera->nombre); ?></h3>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<br>
				<h3>OPCIÓN  <?php echo e(mb_strtoupper($data->nombre_opcion,'UTF-8')); ?></h3>
				<br>
				<h3> MESA DE SINODALES</h3>
				<br>
			</center>
			<h4>
			PRESIDENTE: &emsp;&emsp; &emsp;&emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp;   <?php echo e($data->pg); ?> <?php echo e($data->presidente); ?> <br>
			SECRETARIO: &emsp;&emsp; &emsp; &emsp; &emsp;&emsp; &emsp; &emsp; &emsp;&emsp;    <?php echo e($data->sg); ?> <?php echo e($data->secretario); ?> <br>
			VOCAL PROPIETARIO: &emsp;&emsp;  <?php echo e($data->vpg); ?> <?php echo e($data->vocal_propietario); ?> <br>
			VOCAL SUPLENTE: &emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp; <?php if($vs == '0'): ?> <?php echo e($data->asesor_externo); ?> <?php else: ?> <?php echo e($data->vsg); ?> <?php echo e($data->vocal_suplente); ?> <?php endif; ?>
			</h4>
</div>

</body>
</html>
