

<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col">
    <div class="card">
      <div class="card-body">
				<div class="col-md-12">
					<h3>Grupos de Círculo de estudios</h3>
					<div class="col-md-4">
						<a href="<?php echo e(route('grupocestudio.create')); ?>" class="btn btn-raised btn-primary"><i class="material-icons">add</i></a>
					</div>
					<form action="" method="GET" class="form-horizontal">
						<div class="col-md-6 form-group">
							<input type="text" id="busqueda" name="busqueda" style="text-transform:uppercase;" placeholder="Buscar..." class="form-control">
						</div>
						<div class="col-md-2">
							<button type="submit" class="btn btn-raised btn-primary"><i class="material-icons">search</i></button>
						</div>
					</form>
					<br>
					<br>
					<br>
					<table class="table table-striped table-hover ">
						<thead>
							<tr>
								<th>Tutor</th>
								<th>Materia</th>
								<th>Ciclo Escolar</th>
                <th></th>
							</tr>
						</thead>
						<tbody>
							<?php $__currentLoopData = $grupocestudio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grupo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($grupo->tutor); ?></td>
								<td><strong><?php echo e($grupo->nombre_completo_materia); ?></strong></td>
								<td><strong><?php if($grupo->ciclo_escolar==1): ?> ENERO-JUNIO <?php else: ?> AGOSTO-DICIEMBRE <?php endif; ?></strong></td>
								<td colspan="3" align="center">
									<a href="<?php echo e(route('listar_grupo', $grupo->id)); ?>" data-target="grupo" class="btn btn-raised btn-primary">Detalles</a>
								</td>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>