<?php $__env->startSection('content'); ?>
<?php if(Auth::user()->rol == 'Docente'): ?>
<div class="row">
  <div class="col">
    <div class="card">
      <div class="card-body">
				<div class="col-md-4">
					<a href="<?php echo e(route('titulaciones.create')); ?>" class="btn btn-raised btn-primary"><i class="material-icons">add</i></a>
				</div>
				<form action="" method="GET" class="form-horizontal">
					<div class="col-md-6 form-group">
						<input type="text" id="busqueda" name="busqueda" style="text-transform:uppercase;" placeholder="Buscar..." class="form-control">
					</div>
					<div class="col-md-2">
						<button type="submit" class="btn btn-raised btn-primary"><i class="material-icons">search</i></button>
					</div>
				</form>

				<div class="col-md-12">
					<h3>Proyectos de Titulación Asignados</h3>
					<table class="table table-striped table-hover">
						<thead>
							<tr>
								<th>Numero de Control</th>
								<th>Alumno</th>
								<th>Proyecto</th>
								<th colspan="1">&nbsp;</th>
							</tr>
						</thead>
						<tbody>
							<?php $__currentLoopData = $alumnos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td><?php echo e($alumno->no_de_control); ?></td>
									<td>
										<?php echo e($alumno->apellido_paterno); ?> <?php echo e($alumno->apellido_materno); ?> <?php echo e($alumno->nombre_alumno); ?>

									</td>
									<td>
										<?php echo e($alumno->nombre_proyecto); ?>

									</td>
									<td>
										<a href="<?php echo e(route('proyectoTitulacionCtl.show',$alumno->no_de_control)); ?>" data-target="titulacion" class="btn btn-raised btn-primary">Expediente</a>
									</td>
								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
					<?php echo $alumnos->render(); ?>

				</div>
			</div>
		</div>
	</div>
</div>
<?php endif; ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>