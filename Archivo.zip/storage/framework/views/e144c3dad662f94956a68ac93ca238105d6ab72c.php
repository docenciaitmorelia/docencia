

<?php $__env->startSection('content'); ?>

<div class="row">
  <div class="col">
    <div class="card">
      <div class="card-body">
				<div class="col-md-12">
<?php $__currentLoopData = $alumno; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $al): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<h5><?php echo e($al->no_de_control); ?> <br> <?php echo e($al->apellido_paterno); ?> <?php echo e($al->apellido_materno); ?> <?php echo e($al->nombre_alumno); ?></h5>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php if(file_exists('pdf/AC/'.$al->no_de_control.'.pdf')): ?> <a href="<?php echo e(asset('pdf/AC/'.$al->no_de_control.'.pdf')); ?>" target="_blank">Abrir Constancia de Actividades Comp.</a>
<?php endif; ?>

	 <table class="table table-striped table-hover ">
		<thead>
			<tr>
				<th>Actividad</th>
				<th>N. Créditos</th>
				<th colspan="1">&nbsp;</th>
			</tr>
		</thead>
		<tbody>
			<?php $__currentLoopData = $actividadescomp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actcomp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td>
						<strong><?php echo e($actcomp->actividad); ?></strong>
					</td>
					<td>
						<strong><?php echo e($actcomp->creditos); ?></strong>
					</td>
					<td width="20px">
						<a href="<?php echo e(route('actividadescomp.edit', $actcomp->id)); ?>" class="btn btn-raised btn-primary">
							Editar
						</a>
					</td>
				</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>

	<br>
	<hr size="30">
	<br>
 	<?php if($ncreditos>=5): ?>
 	<form action="<?php echo e(route('crear_constancia_ac', $al->no_de_control)); ?>" method="POST" target="_blank">
		<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
		<div class="col-md-6">
			<label for="oficio" class="control-label">Oficio:</label>
			<input type="text" id="oficio" name="oficio" class="form-control" placeholder="DSC-D-001/2018">
		</div>
		<p class="col-md-12">
			<button type="submit" class="btn btn-raised btn-primary">Generar PDF</button>
			<a href="<?php echo e(route('actividadescomp.index')); ?>" class="btn btn-raised btn-primary">Regresar</a>
		</p>
	</form>
	<?php else: ?>
	<a href="<?php echo e(route('actividadescomp.index')); ?>" class="btn btn-raised btn-primary">Regresar</a>
	<?php endif; ?>
</div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>