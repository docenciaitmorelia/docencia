@extends('layouts.app')

@section('content')
        <div class="col-md-8 col-md-offset-2">
                    <div class="content">
                        <div class="title m-b-md">
                            Modulo de Apoyo a Proyecto Docencia
                        </div>
                    </div>
        </div>
@endsection
