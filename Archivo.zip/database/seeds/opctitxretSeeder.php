<?php

use Illuminate\Database\Seeder;

class opctitxretSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
      DB::table('opctitxrets')->insert([
        'id_opcion_titulacion' => '1',
        'reticula' => '1993',
      ]);

      DB::table('opctitxrets')->insert([
        'id_opcion_titulacion' => '2',
        'reticula' => '1993',
      ]);

      DB::table('opctitxrets')->insert([
        'id_opcion_titulacion' => '3',
        'reticula' => '1993',
      ]);

      DB::table('opctitxrets')->insert([
        'id_opcion_titulacion' => '4',
        'reticula' => '1993',
      ]);

      DB::table('opctitxrets')->insert([
        'id_opcion_titulacion' => '5',
        'reticula' => '1993',
      ]);

      DB::table('opctitxrets')->insert([
        'id_opcion_titulacion' => '6',
        'reticula' => '1993',
      ]);

      DB::table('opctitxrets')->insert([
        'id_opcion_titulacion' => '7',
        'reticula' => '1993',
      ]);

      DB::table('opctitxrets')->insert([
        'id_opcion_titulacion' => '8',
        'reticula' => '1993',
      ]);

      DB::table('opctitxrets')->insert([
        'id_opcion_titulacion' => '9',
        'reticula' => '1993',
      ]);

      DB::table('opctitxrets')->insert([
        'id_opcion_titulacion' => '10',
        'reticula' => '1993',
      ]);
      DB::table('opctitxrets')->insert([
        'id_opcion_titulacion' => '11',
        'reticula' => '1993',
      ]);

      DB::table('opctitxrets')->insert([
        'id_opcion_titulacion' => '12',
        'reticula' => '2004',
      ]);

      DB::table('opctitxrets')->insert([
        'id_opcion_titulacion' => '13',
        'reticula' => '2004',
      ]);

      DB::table('opctitxrets')->insert([
        'id_opcion_titulacion' => '14',
        'reticula' => '2004',
      ]);

      DB::table('opctitxrets')->insert([
        'id_opcion_titulacion' => '15',
        'reticula' => '2004',
      ]);

      DB::table('opctitxrets')->insert([
        'id_opcion_titulacion' => '16',
        'reticula' => '2004',
      ]);

      DB::table('opctitxrets')->insert([
        'id_opcion_titulacion' => '17',
        'reticula' => '2004',
      ]);

      DB::table('opctitxrets')->insert([
        'id_opcion_titulacion' => '18',
        'reticula' => '2004',
      ]);

      DB::table('opctitxrets')->insert([
        'id_opcion_titulacion' => '19',
        'reticula' => '2010',
      ]);

      DB::table('opctitxrets')->insert([
        'id_opcion_titulacion' => '20',
        'reticula' => '2010',
      ]);

      DB::table('opctitxrets')->insert([
        'id_opcion_titulacion' => '21',
        'reticula' => '2010',
      ]);

      DB::table('opctitxrets')->insert([
        'id_opcion_titulacion' => '22',
        'reticula' => '2010',
      ]);

      DB::table('opctitxrets')->insert([
        'id_opcion_titulacion' => '19',
        'reticula' => '2017',
      ]);

      DB::table('opctitxrets')->insert([
        'id_opcion_titulacion' => '20',
        'reticula' => '2017',
      ]);

      DB::table('opctitxrets')->insert([
        'id_opcion_titulacion' => '21',
        'reticula' => '2017',
      ]);

      DB::table('opctitxrets')->insert([
        'id_opcion_titulacion' => '22',
        'reticula' => '2017',
      ]);

    }
}
