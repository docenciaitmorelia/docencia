<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MateriasCarrera extends Model
{
    protected $table = 'materias_carreras';
}
