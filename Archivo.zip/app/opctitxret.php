<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class opctitxret extends Model
{
  protected $table = 'opctitxrets';
}
