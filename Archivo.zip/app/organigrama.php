<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class organigrama extends Model
{
    protected $table = 'organigrama';
}
